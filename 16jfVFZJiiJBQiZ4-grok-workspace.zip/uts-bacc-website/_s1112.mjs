import { writeFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { page, pager, toc } from "./_chrome.mjs";

const root = dirname(fileURLToPath(import.meta.url));
const put = (rel, opts) => writeFileSync(join(root, rel), page({ ...opts, file: rel }));

put("sections/section11.html", {
  title: "Other pathways · UTS BAcc Co-op guide",
  description: "UTS BAcc compared with UTS Business, UNSW, USYD, UNSW Co-op and cadetships.",
  body: `
      <p class="kicker">Section 11</p>
      <h1>Other degrees and pathways</h1>
      <p class="deck">Same three-year length as a normal commerce course. The difference is the scholarship, the two internships, the cohort, and how little room you have to redesign the year.</p>
      ${toc([["table","At a glance"],["goals","By career goal"],["uts","Against UTS Business"],["unsw","Against UNSW"],["usyd","Against USYD"],["coop","Against UNSW Co-op"]])}
      <h2 id="table">At a glance</h2>
      <div class="table-scroll"><table class="sticky-col">
        <caption>ATARs, employment rates and salaries are the brief’s approximations. Check current cut-offs.</caption>
        <thead><tr><th scope="col"></th><th scope="col">BAcc</th><th scope="col">UTS Business</th><th scope="col">UNSW Commerce</th><th scope="col">USYD Commerce</th><th scope="col">Big Four cadetship</th><th scope="col">Mid-tier cadetship</th></tr></thead>
        <tbody>
          <tr><th scope="row">Length</th><td>3 years</td><td>3</td><td>3</td><td>3</td><td>4–5</td><td>4–5</td></tr>
          <tr><th scope="row">Internships</th><td>Two 6-month blocks</td><td>You find them</td><td>You find them</td><td>You find them</td><td>Part-time, one firm</td><td>Part-time, one firm</td></tr>
          <tr><th scope="row">Scholarship</th><td>Up to $54,000</td><td>Only a separate one</td><td>Only a separate one</td><td>Only a separate one</td><td>Wage, often fee help</td><td>Wage, often fee help</td></tr>
          <tr><th scope="row">Cohort</th><td>~35</td><td>Hundreds</td><td>The brief says ~1,000 a year</td><td>~1,000 a year</td><td>The firm’s group</td><td>The firm’s group</td></tr>
          <tr><th scope="row">Entry in the brief</th><td>Very high, plus interview</td><td>ATAR around 80</td><td>Around 90–95</td><td>Around 90–95</td><td>High</td><td>Moderate to high</td></tr>
          <tr><th scope="row">Flexibility</th><td>Moderate</td><td>High</td><td>High</td><td>High</td><td>Low</td><td>Low</td></tr>
          <tr><th scope="row">Employment claim</th><td>95%+</td><td>85–90%</td><td>85–90%</td><td>85–90%</td><td>The firm’s job</td><td>The firm’s job</td></tr>
          <tr><th scope="row">Starting pay</th><td>~$65,000</td><td>~$60,000</td><td>~$65,000</td><td>~$60,000</td><td>$60–65,000</td><td>$55–60,000</td></tr>
          <tr><th scope="row">Accreditation</th><td>CA ANZ and CPA, plus 21644</td><td>Can meet the bodies</td><td>Can</td><td>Can</td><td>Can, with firm support</td><td>Can, with firm support</td></tr>
        </tbody>
      </table></div>
      <p>HECS for a standard Commonwealth-supported commerce degree is sketched at about $45,000. Cadet HECS is sketched at $0–$15,000 if the firm pays. Three-year BAcc “earnings” of $99,000–$114,000 only hold if you believe the high internship guess.</p>
      <h2 id="goals">By career goal</h2>
      <div class="table-scroll"><table class="sticky-col">
        <caption>The last column is the brief’s judgement, not a ranking published by the universities.</caption>
        <thead><tr><th scope="col">Goal</th><th scope="col">BAcc</th><th scope="col">Big Four cadetship</th><th scope="col">Straight commerce</th><th scope="col">Brief’s pick</th></tr></thead>
        <tbody>
          <tr><th scope="row">Audit, tax, public practice</th><td>Strongest, tied with a Big Four cadetship</td><td>Strongest</td><td>Solid</td><td>BAcc or Big Four</td></tr>
          <tr><th scope="row">Corporate accounting</th><td>Strongest, because of the corporate sponsors</td><td>Strong, but practice-weighted</td><td>Strong if you add finance, especially at UNSW</td><td>BAcc</td></tr>
          <tr><th scope="row">Investment banking</th><td>A base only</td><td>Useful if the seat is finance advisory</td><td>UNSW finance rated strongest; UTS Business finance also strong</td><td>A finance degree, not BAcc alone</td></tr>
          <tr><th scope="row">Consulting</th><td>Strong</td><td>Strong, direct entry</td><td>UNSW also rated at the top</td><td>BAcc or a Big Four cadetship</td></tr>
          <tr><th scope="row">Analytics</th><td>Strong only with the major</td><td>Only if the seat is data-focused</td><td>A specialist UTS analytics degree, or UNSW information systems</td><td>The specialist degree</td></tr>
        </tbody>
      </table></div>
      <p>Mid-tier cadetships sit a step below Big Four for pure practice and well below BAcc for corporate variety, with less pressure and a real job at the end.</p>
      <h2 id="uts">Against UTS Bachelor of Business</h2>
      <p>Choose BAcc if you want the scholarship, the placements and the cohort, and your record can win a place. Choose the ordinary degree if your ATAR is in the 80s, you may change direction, or you do not want fixed internship semesters. The outcome gap in the brief is 95%+ and about $65,000 versus 85–90% and about $60,000. The lifestyle gap is larger than the salary gap.</p>
      <h2 id="unsw">Against UNSW Commerce</h2>
      <p>The brief calls UNSW a top-three business school and calls BAcc “premier” only as UTS’s phrase. Choose BAcc for the work, the scholarship and a small practical cohort aimed at corporate accounting. Choose UNSW if the university brand, freer subjects, or finance and economics matter more. UNSW in this comparison does not include an interview.</p>
      <h2 id="usyd">Against University of Sydney Commerce</h2>
      <p>The same pattern, with the brief putting USYD starting pay slightly lower (about $60,000) and the course as more traditional and theoretical. Choose it for that campus and that style. Choose BAcc for the work blocks and the money.</p>
      <h2 id="coop">Against UNSW Co-op</h2>
      <p>The brief says UNSW Co-op is a business program, not an accounting one. Its scholarship is sketched at about $18,000–$20,000 a year, with an ATAR around 95 plus an interview. BAcc’s named total is $54,000 across the degree, not per year, and the sponsors are accounting and corporate. Pick UNSW Co-op if you want a co-op without an accounting identity and you can clear the higher ATAR.</p>
      ${pager(["section10.html","Risks and limits"], ["section12.html","Decide"])}
  `,
});

put("sections/section12.html", {
  title: "Decide · UTS BAcc Co-op guide",
  description: "Whether to choose the UTS BAcc co-op, a priority checker, and questions for the BAcc office.",
  body: `
      <p class="kicker">Section 12</p>
      <h1>Evaluation and a way to decide</h1>
      <p class="deck">The brief’s verdict: a strong path if you are a high-achieving student who wants accounting and can live with a fixed, intense calendar. Not a prize to chase if you want a guaranteed firm or a technical finance career.</p>
      ${toc([["for","Reasons to choose it"],["against","Reasons not to"],["fit","Check your priorities"],["ask","Ask UTS these"],["verdict","Bottom line"]])}
      <h2 id="for">Strongest reasons to choose it</h2>
      <ol>
        <li>Up to $54,000, with $45,000 of that described as tax-free.</li>
        <li>A sponsor list that is hard to cold-call your way into.</li>
        <li>Twelve months of full-time work inside the degree, at two employers.</li>
        <li>You finish in three years, then start a graduate salary while many cadets are still studying.</li>
        <li>A cohort of about 35, camps, and a long alumni list.</li>
        <li>Employers in the brief treat the program as a screen. The word “premier” is UTS’s.</li>
        <li>95%+ employment over 37 years.</li>
        <li>CA ANZ and CPA university requirements are designed in, plus subject 21644.</li>
        <li>You can still add finance, analytics, economics or another major.</li>
        <li>Campus life remains in the non-internship semesters, including a final-semester exchange.</li>
      </ol>
      <h2 id="against">Strongest reasons not to</h2>
      <ol>
        <li>About 35 places. ATAR is necessary and not sufficient.</li>
        <li>The calendar is fast and includes study during full-time work.</li>
        <li>Internship semesters do not move.</li>
        <li>Nobody has to hire you.</li>
        <li>You do not choose the company.</li>
        <li>The core is accounting. A second major does not make it a finance degree.</li>
        <li>Exchange is one semester, at the end.</li>
        <li>Leave, or fail the rules, and the rest of the scholarship stops.</li>
        <li>The intense blocks are a poor fit if you need a calm week.</li>
        <li>Almost everything is in Sydney.</li>
      </ol>
      <h2 id="fit">Check your priorities</h2>
      <p>Tick what actually matters. Each box adds weights implied by this guide. It does not know you, and it is not an offer of admission.</p>
      <form class="fit" data-fit>
        <fieldset>
          <legend class="kicker">Select every line that is true for you</legend>
          <label><input type="checkbox" name="priority" value="speed"> I want to finish in three years and earn a full salary sooner.</label>
          <label><input type="checkbox" name="priority" value="guarantee"> A graduate job needs to be guaranteed, not just likely.</label>
          <label><input type="checkbox" name="priority" value="scholarship"> A large scholarship matters more than a weekly wage.</label>
          <label><input type="checkbox" name="priority" value="breadth"> I want two industries, not one firm.</label>
          <label><input type="checkbox" name="priority" value="depth"> I want to go deep in one firm and be known there before I graduate.</label>
          <label><input type="checkbox" name="priority" value="campus"> Campus life, societies and a cohort matter to me.</label>
          <label><input type="checkbox" name="priority" value="calm"> I want a standard pace and less academic pressure.</label>
          <label><input type="checkbox" name="priority" value="corporate"> Corporate accounting attracts me at least as much as public practice.</label>
          <label><input type="checkbox" name="priority" value="ib"> My real target is investment banking or highly technical finance.</label>
          <label><input type="checkbox" name="priority" value="steady"> I need income every year I am studying, not only in internship blocks.</label>
          <label><input type="checkbox" name="priority" value="flexible"> I want room to change majors, semesters or direction.</label>
          <label><input type="checkbox" name="priority" value="atar"> My ATAR is likely to sit under 90, even if the rest of my record is strong.</label>
        </fieldset>
        <div class="actions">
          <button class="button" type="submit">Show the lean</button>
          <button class="button secondary" type="button" data-fit-reset>Clear</button>
        </div>
        <div class="result" data-fit-result tabindex="-1" aria-live="polite"></div>
      </form>
      <div class="grid-2">
        <article class="card"><h3>Who the brief pictures as suited</h3><p>ATAR usually 90 or above, real activities outside class, a clear interest in accounting, comfort with intensity, and enough organisation to hold work and study in the same week. Curious about companies, not only audit firms.</p></article>
        <article class="card"><h3>Who should look elsewhere</h3><p>You want less pressure, a guaranteed employer, a city other than Sydney, a non-business career, or a finance degree aimed at investment banking. An ATAR under 90 is not an automatic no, but the other four criteria then have to be obviously strong.</p></article>
      </div>
      <h2 id="ask">Ask UTS these</h2>
      <p>Office named in the source: <a href="mailto:carin.alberts@uts.edu.au">carin.alberts@uts.edu.au</a>, 02 9514 3579.</p>
      <ol>
        <li>Do sponsors pay interns, and what were last year’s weekly rates? The brief never says, and its estimates contradict each other.</li>
        <li>What are the confirmed scholarship dollars for your intake? The brief mentions 2027 increases and also prints $17,500 / $18,000 / $9,500 / $9,500.</li>
        <li>In which semester do students take 21644 Law and Ethics for Managers?</li>
        <li>How are internships allocated, and what share of students get their nominated sector?</li>
        <li>What share of the last cohort received a sponsor offer, versus any offer?</li>
        <li>Which of the two subject calendars is real, including where Accounting Standards sits?</li>
        <li>What is the student contribution next year? Is it the same as the Bachelor of Business?</li>
        <li>Which application dates apply? The printed timeline mixes 2025 deadlines with a 2026 interview and a January 2027 start.</li>
        <li>Is there accommodation support? Can exchange ever replace an internship? The brief says no to the second. Confirm both.</li>
      </ol>
      <h2 id="verdict">Bottom line</h2>
      <div class="callout callout-good"><p class="callout-label">Yes, if this is you</p><p>You can credibly compete for 35 places, you want accounting or corporate work beside it, you like two employers and a cohort, and you would rather finish fast than be employed by a named firm from day one.</p></div>
      <div class="callout callout-bad"><p class="callout-label">No, if this is you</p><p>You need a guaranteed job, a calmer pace, a city other than Sydney, or a degree aimed at investment banking or data science. A cadetship or a straight commerce degree is the more honest fit.</p></div>
      <p>Used on purpose, the co-op is one of the more concrete accounting starts in the country: money, work and a network, on a clock. Used because it sounds elite, it is a hard three years pointed at a career you may not want.</p>
      ${pager(["section11.html","Other pathways"], null)}
  `,
});

console.log("11-12");
