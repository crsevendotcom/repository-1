import { writeFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { page, pager, toc } from "./_chrome.mjs";

const root = dirname(fileURLToPath(import.meta.url));
const put = (rel, opts) => writeFileSync(join(root, rel), page({ ...opts, file: rel }));

put("sections/section7.html", {
  title: "How to apply · UTS BAcc Co-op guide",
  description: "UTS BAcc eligibility, five selection criteria, interview day and the dates to confirm.",
  body: `
      <p class="kicker">Section 07</p>
      <h1>Entry requirements, applications and selection</h1>
      <p class="deck">Australian citizens and permanent residents only. There is no fixed ATAR, but the band the program talks about is 90 to 99.95. The interview is half the story.</p>
      ${toc([["who","Who can apply"],["five","Five things they assess"],["steps","Steps"],["dates","Dates, including a clash"],["day","Interview day"],["offer","Offers"]])}
      <h2 id="who">Who can apply</h2>
      <ul class="checks"><li>Australian citizens.</li><li>Permanent residents.</li></ul>
      <ul class="crosses"><li>International students. The brief says other UTS programs exist for them. This co-op is not one.</li></ul>
      <p>No minimum ATAR is published. Intakes are described as ranging from 90 to 100. A high ATAR helps a thinner application. An ATAR of 90 or slightly under can still succeed if the other criteria are strong. “Slightly under” is the program’s phrase, not a promise.</p>
      <h2 id="five">Five things they assess</h2>
      <p>Every criterion is marked high weight. The panel wants a reason to pick you ahead of other strong applicants, not a single right answer.</p>
      <div class="table-scroll"><table>
        <caption>No numeric weighting is published.</caption>
        <thead><tr><th scope="col">Criterion</th><th scope="col">What they want</th><th scope="col">How to show it</th></tr></thead>
        <tbody>
          <tr><td>Interest in accounting</td><td>A real reason for an accounting-based career</td><td>Reading, conversations, any related experience</td></tr>
          <tr><td>Personal attributes</td><td>Communication, teamwork, problem-solving, stamina</td><td>Specific examples from school, work, activities</td></tr>
          <tr><td>Involvement</td><td>A range, not a single trophy</td><td>Leadership, sport, arts, volunteering, a job</td></tr>
          <tr><td>Leadership</td><td>You have led, or you clearly could</td><td>Roles, or projects you started</td></tr>
          <tr><td>Academic ability</td><td>ATAR and the school record</td><td>Results, reports, awards</td></tr>
        </tbody>
      </table></div>
      <h2 id="steps">Steps</h2>
      <ol>
        <li>Submit the UTS online form: details, results, activities, and why accounting.</li>
        <li>List Bachelor of Accounting in UAC. The code in the brief is <strong>601010</strong>. Missing either the form or the preference knocks you out.</li>
        <li>Wait for an interview invitation.</li>
        <li>Attend in business dress.</li>
        <li>Offers arrive by phone and are conditional on ATAR. About 35 places.</li>
      </ol>
      <p>Reaching interview is described as an achievement. Applicant numbers are not published. A success rate under 10% is this guide’s guess, not a UTS statistic.</p>
      <h2 id="dates">Dates in the brief, including a clash</h2>
      <div class="callout callout-warn"><p class="callout-label">Confirm the calendar</p><p>The printed dates jump from 2025 deadlines to interviews in November 2026 and a January 2027 start. That may be a drafting error. Do not miss a real round because this table was copied faithfully.</p></div>
      <div class="table-scroll"><table>
        <caption>Dates exactly as the 2027 timeline is written.</caption>
        <thead><tr><th scope="col">Date written</th><th scope="col">Event</th></tr></thead>
        <tbody>
          <tr><td>Friday 16 May 2025</td><td>Round 1 application deadline</td></tr>
          <tr><td>Friday 10 October 2025</td><td>Round 2 application deadline</td></tr>
          <tr><td>Mid-October 2025</td><td>Round 1 interview invitations</td></tr>
          <tr><td>November 2025</td><td>Round 2 interview invitations</td></tr>
          <tr><td>9–13 November 2026</td><td>Interview period</td></tr>
          <tr><td>13 November 2026</td><td>Deferment application deadline</td></tr>
          <tr><td>Mid-December 2026</td><td>Offers by phone</td></tr>
          <tr><td>Thursday 7 January 2027</td><td>Orientation, then six weeks of classes and a camp</td></tr>
        </tbody>
      </table></div>
      <h2 id="day">Interview day</h2>
      <dl class="dl">
        <dt>Place</dt><dd>UTS Business School, Building 8, 14–28 Ultimo Road, Ultimo.</dd>
        <dt>Dress</dt><dd>Business attire. A suit is preferred. The brief says no casual clothes.</dd>
        <dt>Group activity</dt><dd>About one hour. Icebreaker and a presentation. They watch how you contribute.</dd>
        <dt>Interview</dt><dd>About 30 minutes. Described as a discussion, not an exam.</dd>
        <dt>Panel</dt><dd>One or two sponsor people, UTS academics, and a BAcc graduate.</dd>
      </dl>
      <p>Bring citizenship or permanent residency evidence (passport, citizenship certificate, or Australian birth certificate) plus a copy they can keep, a printed stapled Year 12 report, two referee names on the form, and whatever you need to find the room.</p>
      <p>Know what accountants do inside companies, not only inside chartered firms. Most sponsors are companies. Current news in those industries helps. You do not need a memorised speech.</p>
      <figure class="quote"><blockquote><p>“The best advice we can give you is to relax and be yourself.”</p></blockquote><figcaption>Interview guidelines, as quoted in the brief.</figcaption></figure>
      <h2 id="offer">Offers</h2>
      <p>Phone call, ranked from interview reports plus ATAR, conditional on the ATAR, about 35 places. Accept by the deadline they give you.</p>
      ${pager(["section6.html","Careers"], ["section8.html","Student life"])}
  `,
});

put("sections/section8.html", {
  title: "Student life · UTS BAcc Co-op guide",
  description: "A UTS BAcc week, holidays, societies, the cohort, exchange and support.",
  body: `
      <p class="kicker">Section 08</p>
      <h1>Student experience and lifestyle</h1>
      <p class="deck">The degree is busiest at the start, during internships, and in the final internship semester. Year 2 is the closest thing to an ordinary university year.</p>
      ${toc([["week","A week"],["breaks","Holidays"],["life","Societies, sport, camps"],["cohort","The cohort"],["exchange","Exchange"],["help","Support"],["balance","Compared with other paths"]])}
      <h2 id="week">A week</h2>
      <p>On campus the brief sketches 15–20 contact hours and enough study to reach 40–50 hours all up: lectures, tutorials, group work and a weekend block of 5–10 hours. The January fast-track is the same total with 25–30 hours in the classroom. Internship weeks are 37.5–40 hours of work plus 5–10 hours of study. Evening society events still fit. Competitive sport clashes with office hours.</p>
      <h2 id="breaks">Holidays</h2>
      <ul>
        <li>December: about two or three weeks, because January is teaching.</li>
        <li>Mid-semester breaks: yes, in campus semesters.</li>
        <li>Winter: a normal two or three weeks when you are not on internship.</li>
        <li>Internship months: the employer’s calendar. Annual leave is described as typically two to four weeks. Confirm whether interns receive it.</li>
      </ul>
      <h2 id="life">Societies, sport, camps</h2>
      <p>Named groups: a BAcc society, the business school society, an accounting society, and more than 100 other clubs. Sport includes gyms, pools, fields and inter-university teams. Camps are part of the program: orientation in first year, a development camp in second year, a leadership bootcamp in third year. None run during internships.</p>
      <p>Varsha Badrinath’s first-year note praises the library, societies and practical classes. Malini Raj says the time together produced friendships she expects to keep. Both are testimonials in the program materials.</p>
      <h2 id="cohort">The cohort</h2>
      <p>About 35 people share the same odd calendar. The brief calls it a family. Older cohorts mentor. The closeness can feel like pressure if you wanted a more anonymous degree. There is no part-time or online version.</p>
      <h2 id="exchange">Exchange</h2>
      <p>Yes, in year 3 spring only, one semester, full credit, still enrolled at UTS, still graduating on time. The brief cites 248 agreements in 50 countries, including NUS, Hong Kong University, Tokyo, Amsterdam, Copenhagen Business School, Manchester, California, NYU and Toronto. You cannot swap an internship for exchange.</p>
      <h2 id="help">Support</h2>
      <p>Small classes, tutorials, peer tutors, academic advisers, alumni and sponsor mentors, the internship supervisor, three camps and guest lectures.</p>
      <h2 id="balance">Compared with other paths</h2>
      <div class="table-scroll"><table class="sticky-col">
        <caption>“Pressure” here is the brief’s label, not a clinical measure.</caption>
        <thead><tr><th scope="col">Path</th><th scope="col">Balance</th><th scope="col">Gain</th><th scope="col">Cost</th></tr></thead>
        <tbody>
          <tr><th scope="row">BAcc</th><td>Moderate to high</td><td>Campus plus real work</td><td>Less free time in the intense blocks</td></tr>
          <tr><th scope="row">Big Four cadetship</th><td>Moderate</td><td>Steady load and a job</td><td>Less university, locked to a firm</td></tr>
          <tr><th scope="row">Mid-tier cadetship</th><td>Moderate</td><td>Often calmer, varied work</td><td>Smaller brand</td></tr>
          <tr><th scope="row">Traditional commerce</th><td>Lower</td><td>Ordinary flexibility</td><td>You organise your own experience</td></tr>
        </tbody>
      </table></div>
      ${pager(["section7.html","How to apply"], ["section9.html","Sponsors"])}
  `,
});

put("sections/section9.html", {
  title: "Sponsors and network · UTS BAcc Co-op guide",
  description: "How UTS BAcc sponsorship works, events, mentoring and alumni.",
  body: `
      <p class="kicker">Section 09</p>
      <h1>Sponsors, networking and professional development</h1>
      <p class="deck">Sponsors pay into the program, host the internships, and sit close to hiring. The list is a strength and a boundary: your placements come from this pool.</p>
      ${toc([["list","Who is named"],["model","How sponsorship works"],["events","Events and mentoring"],["hire","Hiring before you graduate"],["alumni","Alumni"]])}
      <h2 id="list">Who is named</h2>
      <p>The inventory, grouped by industry, is on the internships page. The director’s line is to compare that list with any other Australian business degree. Christopher Wiseman, a senior finance manager at Lendlease, is quoted saying the two placements set graduates apart, and that Lendlease’s support follows the quality of the students. Count the list as “28+”. Thinkmill appears only in the longer table. Ask which sponsors are taking people in your year.</p>
      <h2 id="model">How sponsorship works</h2>
      <dl class="dl">
        <dt>Money</dt><dd>UTS and sponsors fund the program together. The brief does not publish each firm’s contribution. Sponsor money is described as covering scholarships, program costs and student development.</dd>
        <dt>Besides cash</dt><dd>Internship seats, supervision, a voice on steering, comments on the curriculum, and time in recruitment.</dd>
        <dt>What they get</dt><dd>An early look at a selected cohort, a brand attached to the degree, and a chance to shape people they might hire.</dd>
      </dl>
      <p>Students are not described as paying extra for camps, placement supervision or recruitment events.</p>
      <h2 id="events">Events and mentoring</h2>
      <ul>
        <li>Office visits, dinners with managers, guest lectures, recruitment presentations.</li>
        <li>Sponsor staff at orientation, the development camp and the leadership bootcamp.</li>
        <li>Workshops grouped as technical (software, modelling, data), interpersonal, industry briefings, and job-search skills.</li>
        <li>Mentors from sponsors, alumni and older students, plus your placement supervisor.</li>
      </ul>
      <h2 id="hire">Hiring before you graduate</h2>
      <p>The formal window is the first six months of year 3: presentations, applications, interviews, conditional offers. Some sponsors move earlier for strong interns. Most offers are described as landing 6–12 months before the end. Use 95%+ as the careful historical employment figure. A slide-style line says 100%.</p>
      <h2 id="alumni">Alumni</h2>
      <p>About 1,300 people over 37 years, in Australia and overseas. Malini Raj’s quote is that the contacts can help with study, advice or jobs. Named senior alumni: Lauren Davis at Dexus (2007), Chris Thompson at THE ICONIC (2005), Brendan Dunne at Allianz (2003), who has said he stayed after his first internship. Three stories are not a destiny. They show why the network is the point of the program.</p>
      ${pager(["section8.html","Student life"], ["section10.html","Risks and limits"])}
  `,
});

put("sections/section10.html", {
  title: "Risks and limits · UTS BAcc Co-op guide",
  description: "Downsides of the UTS BAcc co-op: workload, placement luck, scholarship loss and opportunity cost.",
  body: `
      <p class="kicker">Section 10</p>
      <h1>Risks, disadvantages and limitations</h1>
      <p class="deck">The program is generous and narrow at the same time. Most of the risk is mismatch: the calendar, the employer you are given, or a career that is not really accounting.</p>
      ${toc([["load","Workload"],["place","Placement luck"],["rules","Losing the scholarship"],["job","No guaranteed job"],["focus","An accounting-shaped degree"],["cost","Opportunity cost"],["life","Exchange, city, obligations"]])}
      <h2 id="load">Workload</h2>
      <p>January fast-track, subjects during both internships, and 40–50 hour weeks in the intense blocks. That can burn people out and makes a second heavy commitment hard. There is support. There is not spare time.</p>
      <h2 id="place">Placement luck</h2>
      <ul>
        <li>You nominate a sector. Vacancies, results and the sponsor’s needs decide the rest.</li>
        <li>The first role is assigned. The second allows a preference, still without a guarantee.</li>
        <li>A real scenario in the brief: wanting markets and getting property accounting.</li>
        <li>What helps: say what you want, keep results high, and treat an off-target seat as still useful.</li>
      </ul>
      <p>A poor review does not automatically expel you. It can weaken the next allocation and a graduate offer. Monthly check-ins are the moment to correct course.</p>
      <h2 id="rules">Losing the scholarship</h2>
      <p>You keep it by passing and by following the disciplinary rules. There is no published GPA floor. Repeated failure can mean probation, loss of the scholarship, or exclusion. Leave, and future payments stop. Money already received is not repaid, except that a disciplinary exit may involve a debt the brief does not define. A transfer into an ordinary degree is described as possible. You do not keep the remaining scholarship or the internship machinery.</p>
      <p>Missing the $9,500 incentive is not the same thing. It means a sponsor did not hire you on the bonus terms.</p>
      <h2 id="job">No guaranteed job</h2>
      <p>This is the cleanest difference from a cadetship. Historical employment is excellent and still not 100% in the director’s figure. You compete in year 3. Results, reviews, the network and interviews all matter. Backups named: employers outside the list, further study, and other business roles.</p>
      <h2 id="focus">An accounting-shaped degree</h2>
      <ul>
        <li>Accounting careers: the brief rates these as the direct fit, including the professional subjects and the work year.</li>
        <li>Broader finance: good, better with a finance major, weaker than a dedicated finance degree for investment banking or quantitative work.</li>
        <li>Consulting: possible. A pure consulting target might still prefer a path aimed at that market.</li>
        <li>Analytics: good with the major, not a substitute for a technical data degree.</li>
      </ul>
      <h2 id="cost">Opportunity cost</h2>
      <p>Against a traditional degree, the brief’s BAcc student earns more during university. Against a cadetship, one table shows BAcc ahead on early full salary and another shows the cadet ahead on five-year cash. See the cadetship page. Costs that do not depend on the dollars: less calendar time at work than a multi-year cadetship, no freedom to rearrange semesters, and a sponsor map that is a Sydney map.</p>
      <h2 id="life">Exchange, geography, obligations</h2>
      <p>Exchange exists only in the last semester. A gap year is the one-year deferral, if granted. There is no employment bond: you may refuse sponsor offers. The scholarship stops if you stop meeting the rules. Tuition is still the normal UTS charge. The brief says there are no hidden program fees beyond ordinary study costs.</p>
      ${pager(["section9.html","Sponsors"], ["section11.html","Other pathways"])}
  `,
});

console.log("7-10");
