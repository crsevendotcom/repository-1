import { mkdirSync, writeFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { page, pager, toc } from "./_chrome.mjs";

const root = dirname(fileURLToPath(import.meta.url));
function put(rel, opts) {
  const file = join(root, rel);
  mkdirSync(dirname(file), { recursive: true });
  writeFileSync(file, page({ ...opts, file: rel }));
}

put("sections/section1.html", {
  title: "Course structure · UTS BAcc Co-op guide",
  description: "How the UTS Bachelor of Accounting Co-op is structured across three years, including internships and fast-track study.",
  body: `
      <p class="kicker">Section 01</p>
      <h1>Course overview and structure</h1>
      <p class="deck">A three-year full-time Bachelor of Accounting with two internships built into the calendar. There is no part-time version.</p>
      ${toc([["what","What it is"],["calendar","Three-year calendar"],["clash","Where the timetables disagree"],["load","Load and class size"],["versus","Against a normal business degree"],["change","Changing, leaving, deferring"]])}
      <h2 id="what">What it is</h2>
      <p>The Bachelor of Accounting Co-operative Scholarship is UTS’s flagship business degree in the program’s own words. Students finish a full-time accounting degree and two six-month industry internships in three years, so they graduate with about one year of professional work already done.</p>
      <p>It is funded co-operatively by UTS and sponsor employers. Sponsors offer placements, help select students, and often hire graduates. Michelle Cook, the program director quoted in the brief, says more than twenty large employers come to the program first for business graduates.</p>
      <dl class="dl">
        <dt>Award</dt><dd>Bachelor of Accounting, three years, full-time only.</dd>
        <dt>Accreditation</dt><dd>Meets Chartered Accountants ANZ and CPA Australia university requirements if you also complete 21644 Law and Ethics for Managers.</dd>
        <dt>Credit points</dt><dd>A standard UTS bachelor load, described as about 144 points and about 24 subjects.</dd>
        <dt>Cohort</dt><dd>About 35 students, against hundreds in a normal major.</dd>
        <dt>2027 start named</dt><dd>Orientation on Thursday 7 January 2027, then a six-week fast-track before autumn.</dd>
      </dl>
      <figure class="quote"><blockquote><p>“UTS BAcc is Australia’s premier business degree. Over twenty of Australia’s largest and most prestigious employers come to us first to recruit their top business graduates.”</p></blockquote><figcaption>Michelle Cook, Director, Bachelor of Accounting, as quoted in the source brief.</figcaption></figure>
      <h2 id="calendar">Three-year calendar</h2>
      <p>Year 1 opens with a January–February fast-track, then autumn on campus and spring on internship. Year 2 is a full campus year. Year 3 opens with the second internship and ends on campus, which is also the only window named for exchange.</p>
      <div class="table-scroll"><table>
        <caption>Internship semesters still include two UTS subjects, studied part-time beside full-time work.</caption>
        <thead><tr><th scope="col">Period</th><th scope="col">Year 1</th><th scope="col">Year 2</th><th scope="col">Year 3</th></tr></thead>
        <tbody>
          <tr><th scope="row">January–February</th><td>Fast-track, about six weeks</td><td>One fast-track subject is named in one table only</td><td>No fast-track named</td></tr>
          <tr><th scope="row">Autumn (Mar–Jun)</th><td>On campus, a heavy core load</td><td>On campus, core plus options</td><td>Internship 2, plus two subjects</td></tr>
          <tr><th scope="row">Spring (Jul–Nov)</th><td>Internship 1, plus two subjects</td><td>On campus, core plus options</td><td>On campus, mostly options. Exchange window.</td></tr>
        </tbody>
      </table></div>
      <ul>
        <li>Internship 1: spring of year 1, July to November.</li>
        <li>Internship 2: autumn of year 3, March to June.</li>
        <li>During each internship the brief says you still complete two UTS subjects.</li>
        <li>The pressure is the January fast-track, not a December summer term. The summer rows in the overview are blank.</li>
      </ul>
      <h2 id="clash">Where the timetables disagree</h2>
      <div class="callout callout-warn"><p class="callout-label">Check with UTS</p><p>The brief contains two calendars that do not match. Do not plan electives from one of them until the handbook for your intake is confirmed.</p></div>
      <div class="table-scroll"><table class="sticky-col">
        <caption>Same program, two maps in the source.</caption>
        <thead><tr><th scope="col">Slot</th><th scope="col">Overview timeline</th><th scope="col">Later semester table</th></tr></thead>
        <tbody>
          <tr><th scope="row">Year 1 spring</th><td>Internship, with study mentioned only in prose</td><td>Australian Corporate Environment, Marketing and Customer Value, plus internship</td></tr>
          <tr><th scope="row">Year 2 fast-track</th><td>Cost Management Systems</td><td>Not listed in the compulsory subject inventory</td></tr>
          <tr><th scope="row">Year 2 spring</th><td>Applied Company Law, Information for Decisions and Control, Australian Corporate Environment, Marketing</td><td>Applied Company Law, Information for Decisions and Control, Accounting Standards and Regulations, plus one option</td></tr>
          <tr><th scope="row">Accounting Standards (21255)</th><td>Year 3 spring in the subject list</td><td>Year 2 spring in the semester table</td></tr>
        </tbody>
      </table></div>
      <p>Both versions agree on the spine: accounting systems and accountability up front, combinations and tax in year 2, audit and a capstone during the second internship, and a block of options you can use for a second major.</p>
      <h2 id="load">Load and a normal university week</h2>
      <ul>
        <li>On-campus contact is described as 15–20 hours a week, plus 20–25 hours of independent study.</li>
        <li>Classes mix lectures, tutorials, group work, presentations and workshops.</li>
        <li>The fast-track is described as 25–30 contact hours a week for six weeks.</li>
        <li>Each subject is described as 6–8 credit points. Core accounting subjects are put at 12–14, with 8–10 options depending on majors.</li>
      </ul>
      <h2 id="versus">Against a normal UTS Bachelor of Business</h2>
      <div class="table-scroll"><table class="sticky-col">
        <caption>Both degrees are three years. The co-op buys structure and loses flexibility.</caption>
        <thead><tr><th scope="col"></th><th scope="col">BAcc Co-op</th><th scope="col">Bachelor of Business, accounting</th></tr></thead>
        <tbody>
          <tr><th scope="row">Internships</th><td>Two six-month placements with sponsors</td><td>Optional, and you find them</td></tr>
          <tr><th scope="row">Scholarship</th><td>Up to $54,000</td><td>No automatic scholarship</td></tr>
          <tr><th scope="row">Cohort</th><td>About 35</td><td>Hundreds in the major</td></tr>
          <tr><th scope="row">Entry</th><td>ATAR plus interview and other criteria</td><td>ATAR</td></tr>
          <tr><th scope="row">Calendar</th><td>Fast-track and fixed internship semesters</td><td>Standard semesters</td></tr>
          <tr><th scope="row">Network</th><td>BAcc alumni and sponsors</td><td>The wider business school</td></tr>
        </tbody>
      </table></div>
      <h2 id="change">Changing, leaving, deferring</h2>
      <ul>
        <li>Inside the degree you can add second majors or sub-majors such as finance, business analytics or economics. That is the flexibility the program actually offers.</li>
        <li>Leaving for another UTS course is described as possible. You would forfeit the remaining scholarship, and internship credit may not transfer.</li>
        <li>Moving universities means applying again and losing the BAcc-specific benefits.</li>
        <li>Deferment is one year only, and only if you apply before offers. The 2027 timeline puts that deadline at 13 November 2026.</li>
      </ul>
      ${pager(null, ["section2.html", "Subjects and majors"])}
  `,
});

put("sections/section2.html", {
  title: "Subjects and majors · UTS BAcc Co-op guide",
  description: "Compulsory UTS BAcc subjects, second majors, assessment, workload and professional accreditation.",
  body: `
      <p class="kicker">Section 02</p>
      <h1>Subjects, majors and academic requirements</h1>
      <p class="deck">Accounting is compulsory. Everything else is how you spend the option slots: a second major, two sub-majors, or a spread of electives.</p>
      ${toc([["core","Compulsory subjects"],["accred","Professional accreditation"],["majors","Second majors"],["design","How to spend the options"],["assess","Assessment and difficulty"],["rules","Staying in the program"],["map","Semester map"]])}
      <h2 id="core">Compulsory subjects</h2>
      <p>Names and codes are as printed in the brief. A few appear in one timetable and not the other.</p>
      <div class="table-scroll"><table>
        <caption>Core subjects named in the brief.</caption>
        <thead><tr><th scope="col">When named</th><th scope="col">Code</th><th scope="col">Subject</th><th scope="col">What the brief says it covers</th></tr></thead>
        <tbody>
          <tr><td>Year 1 fast-track</td><td>21107</td><td>Accounting Information Systems</td><td>Software, data and systems. Examples given include Xero, SAP and advanced Excel.</td></tr>
          <tr><td>Year 1 fast-track</td><td>21108</td><td>Accounting and Accountability</td><td>Fundamentals of accounting, reporting and professional accountability.</td></tr>
          <tr><td>Year 1 autumn</td><td>21109</td><td>Accounting, Business and Society</td><td>Accounting in business and social contexts.</td></tr>
          <tr><td>Year 1 autumn</td><td>21127</td><td>Economics for Business</td><td>Micro and macro principles for business decisions.</td></tr>
          <tr><td>Year 1 autumn</td><td>21110</td><td>Financial Literacy</td><td>Statements, budgeting and financial decisions.</td></tr>
          <tr><td>Year 1 autumn</td><td>21128</td><td>Business and Social Impact</td><td>Ethics, sustainability and social responsibility.</td></tr>
          <tr><td>Year 1 autumn</td><td>21129</td><td>Responsible Evidence-Based Decisions</td><td>Data, critical thinking and evidence-based decisions.</td></tr>
          <tr><td>Year 2 autumn</td><td>21248</td><td>Accounting for Business Combinations</td><td>Groups, consolidations and complex structures.</td></tr>
          <tr><td>Year 2 autumn</td><td>21250</td><td>Taxation Law</td><td>Australian tax, compliance and planning, including GST and fringe benefits.</td></tr>
          <tr><td>Year 2 spring</td><td>21249</td><td>Applied Company Law</td><td>Corporate law, governance and legal frameworks.</td></tr>
          <tr><td>Year 2 spring</td><td>21251</td><td>Information for Decisions and Control</td><td>Management accounting, cost and performance.</td></tr>
          <tr><td>Year 2 spring</td><td>21252</td><td>Australian Corporate Environment</td><td>Regulation and governance. One table moves this into year 1 spring.</td></tr>
          <tr><td>Year 3 autumn</td><td>21253</td><td>Assurance Services and Audit</td><td>Audit standards, risk, controls and external audit.</td></tr>
          <tr><td>Year 3 autumn</td><td>21254</td><td>Business Analysis (capstone)</td><td>An integrative project.</td></tr>
          <tr><td>Year 3 spring in one list</td><td>21255</td><td>Accounting Standards and Regulations</td><td>IFRS and compliance. The other map puts it in year 2 spring.</td></tr>
          <tr><td>Additional</td><td>21644</td><td>Law and Ethics for Managers</td><td>Required for CA ANZ and CPA. The brief does not say which semester.</td></tr>
        </tbody>
      </table></div>
      <p>Cost Management Systems is named as a year 2 fast-track subject in the overview and is missing from this list. Marketing and Customer Value appears as a companion subject, in year 1 spring or year 2 spring depending on the table.</p>
      <h2 id="accred">Professional accreditation</h2>
      <p>The degree is described as meeting CA ANZ and CPA Australia university requirements once 21644 is included. Becoming a CA or CPA still means the professional program (six modules or subjects), about three to four years, and three years of mentored work. The internships are said to count toward that work. Later cost is estimated at about $3,000–$5,000. Sponsors often help with fees and study leave. That help is described as common, not promised.</p>
      <h2 id="majors">Second majors</h2>
      <p>Each second major is eight subjects. The same fields can be a four-subject sub-major. Finance is described as the choice of about 40% of the cohort. Business analytics is described as growing.</p>
      <div class="table-scroll"><table>
        <caption>Second majors named in the brief.</caption>
        <thead><tr><th scope="col">Major</th><th scope="col">Key subjects named</th><th scope="col">Pathways suggested</th></tr></thead>
        <tbody>
          <tr><td>Finance</td><td>Corporate finance, investments, markets, risk</td><td>Investment banking, corporate finance, analysis</td></tr>
          <tr><td>Business analytics</td><td>Data analysis, intelligence, modelling, visualisation</td><td>Analytics and consulting</td></tr>
          <tr><td>Economics</td><td>Micro, macro, econometrics, international</td><td>Analysis, policy, consulting</td></tr>
          <tr><td>Business law</td><td>Commercial, contract, IP, employment</td><td>Compliance and legal consulting</td></tr>
          <tr><td>Information technology</td><td>Systems, databases, IT strategy, digital innovation</td><td>IT consulting and digital change</td></tr>
          <tr><td>International business</td><td>Global business, international marketing, culture, trade</td><td>Trade and multinationals</td></tr>
          <tr><td>Management</td><td>Behaviour, strategy, leadership, change</td><td>Consulting and operations</td></tr>
          <tr><td>Marketing</td><td>Principles, consumer behaviour, digital, brand</td><td>Brand and marketing management</td></tr>
          <tr><td>Human resources</td><td>Strategy, recruitment, performance, industrial relations</td><td>HR and talent</td></tr>
          <tr><td>Advertising and communications</td><td>Strategy, media, digital communications, storytelling</td><td>Advertising and media</td></tr>
        </tbody>
      </table></div>
      <p>Extra sub-majors: a deeper accounting sub-major, innovation and entrepreneurship, and sustainability and social impact. Finance topics highlighted include valuation and capital structure, portfolios, and market instruments. Analytics topics include cleaning data, regression and dashboards. Career notes later mention Excel, Power BI, Tableau, SQL and basic Python. Those are not a promise that every subject teaches all of them.</p>
      <h2 id="design">How to spend the option slots</h2>
      <div class="table-scroll"><table>
        <caption>Option subjects can come from any UTS Business School discipline.</caption>
        <thead><tr><th scope="col">Pattern</th><th scope="col">Shape</th><th scope="col">Best if you want</th></tr></thead>
        <tbody>
          <tr><td>1</td><td>One second major (8)</td><td>Depth in a second field</td></tr>
          <tr><td>2</td><td>Eight electives</td><td>Breadth</td></tr>
          <tr><td>3</td><td>Two sub-majors (4 + 4)</td><td>Two complementary sets</td></tr>
          <tr><td>4</td><td>One sub-major plus four electives</td><td>A focus, with room left</td></tr>
        </tbody>
      </table></div>
      <h2 id="assess">Assessment and difficulty</h2>
      <p>Typical mix: exams 40–60%, assignments 20–30%, group projects 10–20%, quizzes 10–20%, participation 5–10%. Examples: business combinations is 50% exam, 30% group consolidation, 20% mid-semester test. Tax is 45% exam, 35% individual scenario, 20% quiz. The capstone is 40% report, 30% presentation, 20% peer assessment, 10% supervisor feedback.</p>
      <p>Workload is described as high because the calendar is compressed, applied rather than theoretical, with heavy team work. A first-year student quoted in the brief, Varsha Badrinath, says the course is intensive but the small cohort means you are not studying alone.</p>
      <h2 id="rules">Staying in the program</h2>
      <ul>
        <li>You must pass subjects. No minimum GPA is published.</li>
        <li>Repeated failure can mean probation, loss of the scholarship, or exclusion.</li>
        <li>The scholarship also depends on the Bachelor of Accounting Disciplinary Rules, professional conduct, and showing up to classes, internships, camps and activities.</li>
        <li>Missing the recruitment incentive does not by itself remove the base scholarship.</li>
      </ul>
      <h2 id="map">Semester map used in the later table</h2>
      <p>This is the more detailed of the two maps. It conflicts with the overview in section 1. Treat it as one version, not the handbook.</p>
      <div class="table-scroll"><table>
        <caption>OPTION means second major, sub-major or elective.</caption>
        <thead><tr><th scope="col">Semester</th><th scope="col">Compulsory</th><th scope="col">Options</th><th scope="col">Note</th></tr></thead>
        <tbody>
          <tr><td>Year 1 fast-track</td><td>Information systems; Accountability</td><td>None</td><td>Six weeks</td></tr>
          <tr><td>Year 1 autumn</td><td>Five cores: impact, accounting and society, economics, financial literacy, evidence-based decisions</td><td>None</td><td>Heaviest classroom semester</td></tr>
          <tr><td>Year 1 spring</td><td>Australian Corporate Environment; Marketing and Customer Value</td><td>None</td><td>Plus internship 1</td></tr>
          <tr><td>Year 2 autumn</td><td>Business combinations; Taxation law</td><td>2</td><td>Four subjects</td></tr>
          <tr><td>Year 2 spring</td><td>Company law; Decisions and control; Accounting standards</td><td>1</td><td>Four subjects</td></tr>
          <tr><td>Year 3 autumn</td><td>Audit; Capstone</td><td>None</td><td>Plus internship 2</td></tr>
          <tr><td>Year 3 spring</td><td>None in this table</td><td>3</td><td>Exchange can replace this session</td></tr>
        </tbody>
      </table></div>
      ${pager(["section1.html","Course structure"], ["section3.html","Scholarship and money"])}
  `,
});

console.log("1-2");
