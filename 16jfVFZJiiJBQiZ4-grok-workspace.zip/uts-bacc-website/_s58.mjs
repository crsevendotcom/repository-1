import { writeFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { page, pager, toc } from "./_chrome.mjs";

const root = dirname(fileURLToPath(import.meta.url));
const put = (rel, opts) => writeFileSync(join(root, rel), page({ ...opts, file: rel }));

put("sections/section5.html", {
  title: "Cadetship comparison · UTS BAcc Co-op guide",
  description: "UTS BAcc compared with Big Four and mid-tier accounting cadetships.",
  body: `
      <p class="kicker">Section 05</p>
      <h1>Comparison with accounting cadetships</h1>
      <p class="deck">A cadetship is a job with a firm that lets you study. BAcc is a degree that includes two jobs. The better one depends on whether you want a guaranteed seat or a faster, broader start.</p>
      ${toc([["table","Side by side"],["money","Money over time"],["bacc","When co-op is stronger"],["cadet","When a cadetship is stronger"],["choose","Which situation fits"]])}
      <div class="callout callout-warn"><p class="callout-label">These dollar ranges are the brief’s estimates</p><p>Cadet salaries and the BAcc earnings totals are not offers. Internship pay is unconfirmed, and the brief’s wage maths clashes with itself. The 4-year and 5-year tables inside the brief also disagree. Read them as sketches.</p></div>
      <h2 id="table">Side by side</h2>
      <div class="table-scroll"><table class="sticky-col">
        <caption>Deloitte is part of the Big Four idea and is not listed as a BAcc sponsor. EY, KPMG and PwC are.</caption>
        <thead><tr><th scope="col">Factor</th><th scope="col">UTS BAcc</th><th scope="col">Big Four cadetship</th><th scope="col">Mid-tier cadetship</th></tr></thead>
        <tbody>
          <tr><th scope="row">Degree</th><td>Bachelor of Accounting, 3 years</td><td>Commerce or business inside a longer contract</td><td>Same pattern as Big Four</td></tr>
          <tr><th scope="row">Calendar</th><td>3 years</td><td>4–5 years</td><td>4–5 years</td></tr>
          <tr><th scope="row">Work</th><td>Two full-time 6-month blocks</td><td>Part-time, often 3–4 days a week, one firm</td><td>Part-time, one firm</td></tr>
          <tr><th scope="row">Study</th><td>About 2.5 years on campus, compressed</td><td>3–4 years at a normal pace</td><td>3–4 years at a normal pace</td></tr>
          <tr><th scope="row">Cash while enrolled</th><td>Up to $54,000, plus whatever internships pay</td><td>Brief’s range: $20,000–$30,000 a year, often with fee help</td><td>$15,000–$25,000 a year, often with some fee help</td></tr>
          <tr><th scope="row">Job at the end</th><td>Likely, not promised. 95%+ historical employment.</td><td>The firm is the job</td><td>The firm is the job</td></tr>
          <tr><th scope="row">Experience</th><td>Two industries</td><td>Deep in one firm’s method</td><td>Deep, often more varied work</td></tr>
          <tr><th scope="row">Campus</th><td>Strong in non-internship terms. Cohort of ~35.</td><td>Thin</td><td>Thin</td></tr>
          <tr><th scope="row">Freedom later</th><td>You can reject a graduate offer</td><td>Locked to the firm for the contract</td><td>Locked to the firm</td></tr>
          <tr><th scope="row">Pressure</th><td>High academic pace</td><td>Steadier study, firm workload</td><td>Often a notch calmer</td></tr>
          <tr><th scope="row">Entry</th><td>About 35 places, interview, ATAR often 90+</td><td>Competitive firm process</td><td>Moderate to high</td></tr>
          <tr><th scope="row">Apply via</th><td>UAC plus a UTS form</td><td>The firm</td><td>The firm</td></tr>
          <tr><th scope="row">Exchange</th><td>Possible in the last semester</td><td>Only if the firm allows it</td><td>Only if the firm allows it</td></tr>
        </tbody>
      </table></div>
      <h2 id="money">Money over time, as the brief frames it</h2>
      <p>“Earnings” sometimes means cash in, and “net” sometimes subtracts tuition. A cadet with fees paid can look richer at year 5 in one table even though the BAcc graduate has already drawn a full salary. The brief says that earlier full salary can overtake the gap across a career. It does not model past year 5.</p>
      <div class="table-scroll"><table>
        <caption>Three-year comparison. BAcc earnings include the high internship guess.</caption>
        <thead><tr><th scope="col">Path</th><th scope="col">Earnings in the brief</th><th scope="col">Tuition it subtracts</th><th scope="col">Net it claims</th><th scope="col">Work</th></tr></thead>
        <tbody>
          <tr><td>BAcc</td><td>$99,000–$114,000</td><td>~$45,000</td><td>+$54,000 to +$69,000</td><td>1 year full-time</td></tr>
          <tr><td>Big Four cadetship</td><td>$60,000–$90,000</td><td>$0–$15,000</td><td>+$45,000 to +$75,000</td><td>2–3 years part-time</td></tr>
          <tr><td>Mid-tier cadetship</td><td>$45,000–$75,000</td><td>$0–$15,000</td><td>+$30,000 to +$60,000</td><td>2–3 years part-time</td></tr>
        </tbody>
      </table></div>
      <p>One later table puts the BAcc graduate on about $65,000 in year 4 while cadets are still studying, and claims a five-year BAcc lead. A different evaluation table puts five-year BAcc net at +$144,000 to +$159,000 and a Big Four cadetship at +$215,000 to +$250,000. Do not add the tables. The second is less generous to BAcc and says cadetships win five-year cash, while BAcc wins time-to-salary.</p>
      <h2 id="bacc">When the brief says co-op is stronger</h2>
      <ul class="checks">
        <li>You want a full graduate salary one or two years earlier.</li>
        <li>You want two industries, especially banks, property, insurers and consumer companies, not only audit.</li>
        <li>You want campus, societies and a possible exchange.</li>
        <li>You can handle a compressed year and an interview on top of ATAR.</li>
        <li>You do not want a four- or five-year tie to one employer.</li>
      </ul>
      <h2 id="cadet">When the brief says a cadetship is stronger</h2>
      <ul class="checks">
        <li>You want the graduate job written down at the start, and a wage every year.</li>
        <li>You want to be known inside one firm before you graduate.</li>
        <li>You want more calendar time at work. Two or three years part-time can exceed one year full-time.</li>
        <li>You want a standard subject pace, or your ATAR sits under the co-op’s usual band.</li>
        <li>You want a smaller firm’s variety: BDO, Pitcher Partners or Grant Thornton. BDO and Pitcher are also BAcc sponsors.</li>
      </ul>
      <h2 id="choose">A straight choice</h2>
      <div class="grid-3">
        <article class="card"><h3>Choose BAcc if</h3><p>Corporate accounting matters as much as public practice, you can carry an intense year, and you would rather pick an employer at the end.</p></article>
        <article class="card"><h3>Choose Big Four if</h3><p>You already want that firm’s audit, tax or advisory path, and a guaranteed seat matters more than a three-year finish.</p></article>
        <article class="card"><h3>Choose mid-tier if</h3><p>You want the same security with less competition, more attention, or a regional office.</p></article>
      </div>
      ${pager(["section4.html","Internships"], ["section6.html","Careers"])}
  `,
});

put("sections/section6.html", {
  title: "Careers · UTS BAcc Co-op guide",
  description: "UTS BAcc graduate jobs, salaries, progression, CA and CPA, and the limits of an accounting degree.",
  body: `
      <p class="kicker">Section 06</p>
      <h1>Career pathways and graduate outcomes</h1>
      <p class="deck">The program’s own record is a 95%+ employment rate over 37 years and a starting salary around $65,000. Roles fan out from audit into banks, property, insurers and commercial teams.</p>
      ${toc([["stats","Headline numbers"],["roles","Roles by sector"],["paths","How careers move"],["limits","What it does not set up"],["pay","Salary ranges"],["qual","CA and CPA"],["network","Alumni"]])}
      <h2 id="stats">The headline numbers</h2>
      <ul class="stats">
        <li><strong>95%+</strong><span>Employment over 37 years, quoted by the director</span></li>
        <li><strong>~$65,000</strong><span>Average starting salary in the brief</span></li>
        <li><strong>Year 3</strong><span>When most offers are described as landing</span></li>
        <li><strong>37 years</strong><span>How long outcomes are said to have been tracked</span></li>
      </ul>
      <p>Another line says “100% historic employment rate”. Keep both. Neither is a promise. Offers can arrive 6–12 months before the final semester. Employers outside the sponsor list also hire.</p>
      <h2 id="roles">Roles by sector</h2>
      <div class="table-scroll"><table>
        <caption>Starting ranges are the brief’s, not a salary survey.</caption>
        <thead><tr><th scope="col">Sector</th><th scope="col">Typical roles</th><th scope="col">Examples named</th><th scope="col">Start</th></tr></thead>
        <tbody>
          <tr><td>Public accounting</td><td>Graduate, auditor, tax</td><td>EY, KPMG, PwC, BDO, Pitcher Partners</td><td>$60,000–$70,000</td></tr>
          <tr><td>Banking</td><td>Analyst, management accountant, risk</td><td>CBA, Westpac, Macquarie, Perpetual</td><td>$65,000–$75,000</td></tr>
          <tr><td>Property</td><td>Financial accountant, property analyst</td><td>Dexus, Lendlease, Mirvac, Stockland, GPT</td><td>$65,000–$70,000</td></tr>
          <tr><td>Other corporates</td><td>Commercial accountant, analyst</td><td>Coca-Cola, Merivale, THE ICONIC, News Corp</td><td>$60,000–$70,000</td></tr>
          <tr><td>Insurance</td><td>Underwriting accounts, claims, risk</td><td>QBE, Allianz</td><td>$60,000–$65,000</td></tr>
          <tr><td>Government</td><td>Graduate accountant, reporting</td><td>NSW Health, ASX, other agencies</td><td>$60,000–$65,000</td></tr>
        </tbody>
      </table></div>
      <p>Other titles named: financial accountant, management accountant, commercial accountant, tax accountant, treasury analyst. Bank desks named include CBA finance, risk and treasury; Westpac group finance; Macquarie corporate finance and risk; Perpetual fund accounting.</p>
      <h2 id="paths">How careers move</h2>
      <p>The brief sketches public practice from graduate to partner over 10–15 years ($60,000 toward $150,000+), corporate accounting toward CFO ($60,000 toward $200,000+), analysis and commercial partnering over 8–12 years, consulting toward manager, and investment banking from analyst toward director ($80,000 toward $250,000+). At about five years it talks about manager in a firm or finance manager in a company. These are shapes, not medians. Big Four management is claimed in 5–7 years. Mid-tier partner is sketched at 10–12 years, with more varied work. Deloitte is included as a recruiter and is not a listed sponsor.</p>
      <p>Investment banking is marked harder from accounting alone. The path given is a finance major, a relevant internship, then CFA or an MBA. Consulting, including Big Four advisory, is marked a good fit. Analytics is marked excellent if you add that major. Tools named for that path include Excel, Power BI, Tableau, SQL and basic Python.</p>
      <h2 id="limits">What the degree does not set up</h2>
      <p>It prepares you for accounting, commercial finance, advisory, audit, risk and tax. With extra study it can reach investment banking, management consulting, data work or a business of your own. It does not prepare you for software engineering, clinical work, or a creative career. Highly technical finance is called out as needing more than this degree.</p>
      <h2 id="pay">Salary ranges in the brief</h2>
      <div class="table-scroll"><table>
        <caption>Start, about two years, and about five years.</caption>
        <thead><tr><th scope="col">Role</th><th scope="col">Setting</th><th scope="col">Start</th><th scope="col">~2 years</th><th scope="col">~5 years</th></tr></thead>
        <tbody>
          <tr><td>Graduate accountant</td><td>Big Four</td><td>$60–65k</td><td>$70–80k</td><td>$90–110k</td></tr>
          <tr><td>Graduate accountant</td><td>Mid-tier</td><td>$55–60k</td><td>$65–75k</td><td>$80–100k</td></tr>
          <tr><td>Financial analyst</td><td>Corporate</td><td>$65–70k</td><td>$75–85k</td><td>$95–120k</td></tr>
          <tr><td>Management accountant</td><td>Corporate</td><td>$60–65k</td><td>$70–80k</td><td>$85–110k</td></tr>
          <tr><td>Commercial or business analyst</td><td>Corporate or consulting</td><td>$65–70k</td><td>$75–85k</td><td>$90–120k</td></tr>
          <tr><td>Tax adviser</td><td>Public practice</td><td>$60–65k</td><td>$70–80k</td><td>$85–110k</td></tr>
        </tbody>
      </table></div>
      <h2 id="qual">CA and CPA afterwards</h2>
      <p>University requirements are the degree plus 21644. You still need the six-part CA or CPA program, about three to four years, and three mentored years of work. One year of internship is said to count. Cost is sketched at $3,000–$5,000. Sponsors often provide study leave and fee support. Often is not always.</p>
      <h2 id="network">Alumni</h2>
      <p>About 1,300 graduates over 37 years is the scale given. Names: Lauren Davis, Group Financial Controller at Dexus (2007); Chris Thompson, CFO at THE ICONIC (2005); Brendan Dunne, Chief Customer and Operations Officer at Allianz (2003). Malini Raj (2001) is quoted on using the network for study, advice and jobs. Support on top of UTS Careers: the BAcc office, sponsor mentors and alumni mentors.</p>
      ${pager(["section5.html","Versus cadetships"], ["section7.html","How to apply"])}
  `,
});

console.log("5-6");
