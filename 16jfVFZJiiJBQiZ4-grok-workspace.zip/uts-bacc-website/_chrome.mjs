import { dirname, relative } from "node:path";

export const NAV = [
  ["index.html", "00", "Overview"],
  ["sections/section1.html", "01", "Course structure"],
  ["sections/section2.html", "02", "Subjects and majors"],
  ["sections/section3.html", "03", "Scholarship and money"],
  ["sections/section4.html", "04", "Internships"],
  ["sections/section5.html", "05", "Versus cadetships"],
  ["sections/section6.html", "06", "Careers"],
  ["sections/section7.html", "07", "How to apply"],
  ["sections/section8.html", "08", "Student life"],
  ["sections/section9.html", "09", "Sponsors"],
  ["sections/section10.html", "10", "Risks and limits"],
  ["sections/section11.html", "11", "Other pathways"],
  ["sections/section12.html", "12", "Decide"],
];

export function relLink(fromFile, toFile) {
  const rel = relative(dirname(fromFile), toFile).replaceAll("\\", "/");
  if (rel === "") return "./";
  return rel.startsWith(".") ? rel : `./${rel}`;
}

export function page({ file, title, description, body }) {
  const href = (target) => relLink(file, target);
  const links = NAV.map(
    ([target, num, label]) =>
      `<li><a href="${href(target)}"><span class="num">${num}</span><span>${label}</span></a></li>`,
  ).join("");
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>${title}</title>
  <meta name="description" content="${description}">
  <link rel="icon" href="${href("favicon.svg")}" type="image/svg+xml">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,500;9..144,620&family=Source+Sans+3:ital,wght@0,400;0,600;0,700;1,400&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="${href("css/styles.css")}">
</head>
<body>
  <a class="skip" href="#content">Skip to content</a>
  <button class="backdrop" type="button" data-nav-backdrop hidden aria-label="Close menu"></button>
  <div class="shell">
    <aside id="site-nav" class="sidenav">
      <a class="brand" href="${href("index.html")}">
        <span class="mark" aria-hidden="true">BA</span>
        <span class="brand-text">
          <p class="brand-kicker">Decision guide</p>
          <p class="brand-name">UTS BAcc Co-op</p>
        </span>
      </a>
      <nav aria-label="Guide sections">
        <ol>${links}</ol>
      </nav>
      <p class="side-note">Not an official UTS page. Estimates stay labeled. Conflicts in the source are shown, not smoothed over.</p>
    </aside>
    <div class="maincol">
      <header class="topbar">
        <button class="nav-toggle" type="button" data-nav-toggle aria-expanded="false" aria-controls="site-nav">Menu</button>
        <p>Bachelor of Accounting Co-operative Scholarship · reading guide</p>
      </header>
      <div class="progress" aria-hidden="true"><span data-progress></span></div>
      <main id="content" class="content">
${body}
      </main>
      <footer class="site-footer content">
        <p>Independent guide assembled from the supplied program notes. It is not published by the University of Technology Sydney. Sponsors, fees, scholarship rules and dates change.</p>
        <p>Office named in the source: <a href="mailto:carin.alberts@uts.edu.au">carin.alberts@uts.edu.au</a> · 02 9514 3579.</p>
      </footer>
    </div>
  </div>
  <script src="${href("js/main.js")}"></script>
</body>
</html>
`;
}

export function toc(items) {
  const lis = items.map(([id, label]) => `<li><a href="#${id}">${label}</a></li>`).join("");
  return `<nav class="toc" aria-label="On this page"><strong>On this page</strong><ol>${lis}</ol></nav>`;
}

export function pager(prev, next) {
  const left = prev
    ? `<a href="${prev[0]}"><span>Previous</span><strong>${prev[1]}</strong></a>`
    : "<span></span>";
  const right = next
    ? `<a class="next" href="${next[0]}"><span>Next</span><strong>${next[1]}</strong></a>`
    : "<span></span>";
  return `<nav class="pager" aria-label="Adjacent sections">${left}${right}</nav>`;
}
