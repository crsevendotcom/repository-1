import { mkdirSync, writeFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { page, pager, toc } from "./_chrome.mjs";

const root = dirname(fileURLToPath(import.meta.url));
const put = (rel, opts) => {
  const file = join(root, rel);
  mkdirSync(dirname(file), { recursive: true });
  writeFileSync(file, page({ ...opts, file: rel }));
};

put("index.html", {
  title: "UTS BAcc Co-op decision guide",
  description:
    "A clear guide to the UTS Bachelor of Accounting Co-operative Scholarship: structure, money, internships, cadetships, careers, entry and risks.",
  body: `
      <p class="kicker">For students comparing accounting degrees and cadetships</p>
      <div class="hero">
        <div>
          <h1>Should you do the UTS Bachelor of Accounting Co-op?</h1>
          <p class="deck">A three-year accounting degree, two six-month industry placements, a cohort of about 35, and a scholarship of up to $54,000. This guide turns a long program brief into something you can actually compare.</p>
          <p class="lead">UTS calls it Australia’s premier business degree, backed by 28 or more sponsor employers who recruit from it first. That claim is the program’s own. These pages separate what the brief states, what it estimates, and what it leaves unanswered.</p>
        </div>
        <ul class="stats">
          <li><strong>$54,000</strong><span>Maximum scholarship, partly conditional</span></li>
          <li><strong>2 × 6 months</strong><span>Full-time internships inside the degree</span></li>
          <li><strong>~35 places</strong><span>ATAR often 90 to 100, plus an interview</span></li>
          <li><strong>95%+</strong><span>Graduate employment, tracked over 37 years</span></li>
        </ul>
      </div>
      <div class="callout callout-info">
        <p class="callout-label">How to read this</p>
        <p>Base scholarship amounts are stated as program rules. Internship wages, some salary totals and parts of the timetable disagree inside the source. Those clashes are marked “Check with UTS” rather than averaged into a false figure.</p>
      </div>
      <div class="grid-2">
        <article class="card">
          <h2>The case for it</h2>
          <ul class="checks">
            <li>Graduate in three years with a year of full-time work already done.</li>
            <li>Up to $45,000 tax-free, plus a $9,500 taxable bonus if a sponsor hires you.</li>
            <li>Two different employers, mostly large Sydney corporates, not one firm for the whole degree.</li>
            <li>Small cohort, camps, and a long alumni network. CA ANZ and CPA study requirements are built in, plus one extra law subject.</li>
          </ul>
          <p><a class="more" href="sections/section12.html">See who it suits</a></p>
        </article>
        <article class="card">
          <h2>The case for pausing</h2>
          <ul class="crosses">
            <li>About 35 places. Academics are only one of five selection tests.</li>
            <li>Fast-track January subjects and study during full-time internships.</li>
            <li>No guaranteed graduate job, unlike a cadetship.</li>
            <li>You nominate a sector. UTS allocates the actual employer. Internship pay is not confirmed in the brief.</li>
          </ul>
          <p><a class="more" href="sections/section5.html">Compare with cadetships</a></p>
        </article>
      </div>
      <h2 id="contents">Twelve sections</h2>
      <form class="filter" role="search" data-filter-form>
        <div>
          <label for="q">Find a topic</label>
          <input id="q" type="search" data-filter placeholder="Try scholarship, audit, ATAR, exchange" autocomplete="off">
        </div>
      </form>
      <p class="empty" data-filter-empty hidden>Nothing matches that search. Try a shorter word.</p>
      <ol class="contents">
        <li data-keywords="overview structure timeline internship semesters degree credit points business difference defer"><a href="sections/section1.html"><span class="num">01</span><span>Course overview and structure<small>What the degree is, how the three years run, and how it differs from a normal Bachelor of Business.</small></span></a></li>
        <li data-keywords="subjects majors finance analytics electives accreditation cpa ca assessment workload law ethics"><a href="sections/section2.html"><span class="num">02</span><span>Subjects, majors and academic rules<small>Core accounting subjects, second majors, assessment, and the pass standard.</small></span></a></li>
        <li data-keywords="scholarship money tax centrelink hecs fees internship pay incentive 54000"><a href="sections/section3.html"><span class="num">03</span><span>Scholarship and money<small>What is paid, what is taxable, tuition, and the estimates that do not add up.</small></span></a></li>
        <li data-keywords="internship sponsors placement paid hours coca-cola audit matching"><a href="sections/section4.html"><span class="num">04</span><span>Industry internships<small>When you work, who the sponsors are, how matching works, and what a week looks like.</small></span></a></li>
        <li data-keywords="cadetship big four deloitte ey pwc kpmg comparison salary job guarantee"><a href="sections/section5.html"><span class="num">05</span><span>Cadetship comparison<small>Side-by-side with Big Four and mid-tier cadetships, including the money over time.</small></span></a></li>
        <li data-keywords="career salary employment graduate cfo audit banking consulting alumni"><a href="sections/section6.html"><span class="num">06</span><span>Careers and outcomes<small>Roles, starting pay, progression, and where an accounting degree is a weak fit.</small></span></a></li>
        <li data-keywords="apply atar interview uac eligibility documents timeline 2027"><a href="sections/section7.html"><span class="num">07</span><span>Entry, application and selection<small>Who can apply, the five criteria, interview day, and the dates to confirm.</small></span></a></li>
        <li data-keywords="student life holidays camps exchange societies workload cohort"><a href="sections/section8.html"><span class="num">08</span><span>Student experience<small>A normal week, holidays, societies, the cohort, and exchange.</small></span></a></li>
        <li data-keywords="sponsors networking alumni lendlease ey cba mentoring"><a href="sections/section9.html"><span class="num">09</span><span>Sponsors and network<small>How the money model works, events, and the alumni examples.</small></span></a></li>
        <li data-keywords="risks disadvantages workload flexibility job not guaranteed scholarship loss"><a href="sections/section10.html"><span class="num">10</span><span>Risks and limitations<small>Workload, allocation luck, lost scholarship, and opportunity cost.</small></span></a></li>
        <li data-keywords="unsw usyd commerce alternative co-op bachelor of business"><a href="sections/section11.html"><span class="num">11</span><span>Other degrees and pathways<small>BAcc against UTS Business, UNSW, USYD, and cadetships, by career goal.</small></span></a></li>
        <li data-keywords="decision recommendation verdict questions contact fit tool"><a href="sections/section12.html"><span class="num">12</span><span>Decision and questions for UTS<small>Who should choose it, a priority checker, and what to ask the office.</small></span></a></li>
      </ol>
      <h2>Snapshot, before the long tables</h2>
      <div class="table-scroll">
        <table class="sticky-col">
          <caption>Short comparison. Dollar ranges later in the guide are the source’s own estimates, not offers.</caption>
          <thead>
            <tr><th scope="col">Question</th><th scope="col">BAcc Co-op</th><th scope="col">Big Four cadetship</th><th scope="col">Standard commerce degree</th></tr>
          </thead>
          <tbody>
            <tr><th scope="row">Time to graduate</th><td>3 years</td><td>Usually 4–5 years</td><td>3 years</td></tr>
            <tr><th scope="row">Work while studying</th><td>Two full-time 6-month blocks</td><td>Part-time across the degree, one firm</td><td>Only if you find it</td></tr>
            <tr><th scope="row">Money from the program</th><td>Up to $54,000 scholarship. Internship wages unconfirmed.</td><td>Salary, often with tuition support</td><td>None built in</td></tr>
            <tr><th scope="row">Job at the end</th><td>Not guaranteed. Historical employment 95%+.</td><td>Graduate role with that firm is the point of the contract</td><td>You search the market</td></tr>
            <tr><th scope="row">Campus life</th><td>Full-time blocks plus a cohort of ~35</td><td>Thinner, because you are at work most weeks</td><td>The ordinary university year</td></tr>
          </tbody>
        </table>
      </div>
      <p><a class="more" href="sections/section1.html">Start with how the degree is built</a></p>
  `,
});

console.log("index");
