import { writeFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { page, pager, toc } from "./_chrome.mjs";

const root = dirname(fileURLToPath(import.meta.url));
const put = (rel, opts) => writeFileSync(join(root, rel), page({ ...opts, file: rel }));

put("sections/section3.html", {
  title: "Scholarship and money · UTS BAcc Co-op guide",
  description: "UTS BAcc scholarship amounts, tax, Centrelink, tuition, and the internship-pay estimates that do not match.",
  body: `
      <p class="kicker">Section 03</p>
      <h1>Scholarship and financial benefits</h1>
      <p class="deck">The base scholarship is specific. The internship wage is not. Read those as different kinds of fact.</p>
      ${toc([["pay","What is paid"],["rules","Conditions"],["tax","Tax and Centrelink"],["wages","Are internships paid?"],["fees","Tuition and other costs"],["loss","If you fail or leave"],["model","Three-year picture"]])}
      <h2 id="pay">What is paid</h2>
      <div class="table-scroll"><table>
        <caption>Fortnightly amounts go to a bank account across calendar years, not academic years.</caption>
        <thead><tr><th scope="col">Year</th><th scope="col">Amount</th><th scope="col">When</th><th scope="col">Status</th></tr></thead>
        <tbody>
          <tr><td>1</td><td>$17,500</td><td>1 January to 31 December, fortnightly</td><td>Automatic if you are in the program</td></tr>
          <tr><td>2</td><td>$18,000</td><td>1 January to 31 December, fortnightly</td><td>Automatic</td></tr>
          <tr><td>3, first half</td><td>$9,500</td><td>1 January to 30 June, fortnightly</td><td>Automatic</td></tr>
          <tr><td>3, recruitment incentive</td><td>$9,500</td><td>Lump sum before 30 June of year 3</td><td>Only if a sponsor recruits you into the relevant service line</td></tr>
          <tr><th scope="row">Total</th><td>$54,000</td><td>About 2.5 years of payments</td><td>$45,000 base, plus the conditional $9,500</td></tr>
        </tbody>
      </table></div>
      <p>The brief says increases were approved from 2027 and also prints these figures. Confirm the dollars for your intake. The first payment is described as starting 1 January of year 1.</p>
      <h2 id="rules">Conditions</h2>
      <p>The base $45,000 depends on the Bachelor of Accounting Disciplinary Rules: pass your subjects, take part in classes, internships, camps and activities, and behave professionally. There is no published GPA cut-off. Consistent failure can trigger review.</p>
      <p>The $9,500 incentive needs all of these: you take part in the BAcc graduate recruitment process; a sponsor organisation recruits you; the role is in the service line of the sponsor that supports the program. You do not have to accept a sponsor job. Sponsors are asked to limit hiring so it stays in proportion to what they contribute. Recruitment sits in the first six months of year 3. The incentive is not paid if you are hired outside the sponsor group.</p>
      <h2 id="tax">Tax and Centrelink</h2>
      <ul>
        <li>Base scholarship ($45,000): described as not taxable.</li>
        <li>Recruitment incentive ($9,500): described as taxable income.</li>
        <li>Both must be declared for Centrelink. That can change Youth Allowance even when the base amount is not taxed.</li>
      </ul>
      <h2 id="wages">Are internships paid?</h2>
      <div class="callout callout-warn"><p class="callout-label">Not stated. The brief’s own estimates also clash.</p><p>The documents never say that sponsors pay a wage. They call the blocks full-time professional placements at large employers, and they note that similar co-op programs usually pay. Ask UTS directly.</p></div>
      <ul>
        <li>One passage estimates year 1 at $20,000–$25,000 for six months ($400–$500 a week) and year 3 at $25,000–$35,000 ($500–$700 a week).</li>
        <li>$400 a week for 26 weeks is about $10,400, not $20,000. $700 a week for 26 weeks is about $18,200, not $35,000.</li>
        <li>A later passage estimates $400–$700 a week and says six months equals $10,000–$21,000. That weekly rate matches the second total, not the $20,000–$35,000 line.</li>
      </ul>
      <p>Later “total earnings” of about $99,000–$114,000 add the $54,000 scholarship to the higher internship guess. If the consistent weekly rates are right, and only if the placements are paid, internship cash is closer to $10,000–$21,000 each. Do not treat either total as money you will receive.</p>
      <h2 id="fees">Tuition and other costs</h2>
      <p>BAcc students are not exempt from HECS-HELP. The brief uses about $15,000–$18,000 a year for a Commonwealth-supported place, and about $45,000–$54,000 over three years. Australian citizens can usually defer through HECS-HELP. Permanent residents who are not citizens are described as likely needing to pay the student contribution up front. The scholarship can cover fees in cash-flow terms. It does not cancel the charge.</p>
      <div class="table-scroll"><table>
        <caption>Other costs the brief estimates. Camps are described as included.</caption>
        <thead><tr><th scope="col">Item</th><th scope="col">Estimate</th><th scope="col">Note</th></tr></thead>
        <tbody>
          <tr><td>Textbooks and materials</td><td>$500–$1,000 a year</td><td>Accounting texts can be expensive</td></tr>
          <tr><td>Student services fee</td><td>About $300 a year</td><td>Compulsory</td></tr>
          <tr><td>Transport</td><td>$500–$1,500 a year</td><td>UTS and internship sites</td></tr>
          <tr><td>Accommodation</td><td>$10,000–$20,000 a year</td><td>Only if you are not living at home</td></tr>
          <tr><td>Business clothes</td><td>$500–$1,500</td><td>Interviews and internships</td></tr>
        </tbody>
      </table></div>
      <p>Extra part-time work is not banned, but it is not recommended in teaching semesters, and it does not fit full-time internship hours or the January fast-track.</p>
      <h2 id="loss">If you fail, withdraw, or lose the scholarship</h2>
      <div class="table-scroll"><table>
        <caption>Amounts already paid are not repaid if you leave or are excluded. A disciplinary exit may also create a debt the brief does not define.</caption>
        <thead><tr><th scope="col">What happens</th><th scope="col">Scholarship</th><th scope="col">Study</th></tr></thead>
        <tbody>
          <tr><td>Fail a subject, then pass the retake</td><td>Can continue</td><td>Retake may delay you and add a fee</td></tr>
          <tr><td>Withdraw</td><td>Future payments stop</td><td>Transfer to a regular degree is described as possible</td></tr>
          <tr><td>Excluded for academic or disciplinary reasons</td><td>Future payments stop</td><td>You cannot continue in BAcc</td></tr>
          <tr><td>No sponsor job</td><td>You lose only the $9,500 incentive</td><td>You can still graduate</td></tr>
        </tbody>
      </table></div>
      <h2 id="model">Three-year picture, with the assumptions showing</h2>
      <p>This is the brief’s optimistic table. It assumes internship wages at the higher, inconsistent range, and tuition of about $15,000 a year. Living costs are excluded. “Net” is scholarship plus guessed wages, minus tuition. It is not cash in your account.</p>
      <div class="table-scroll"><table>
        <caption>Internship dollars are estimates. The incentive is conditional.</caption>
        <thead><tr><th scope="col">Year</th><th scope="col">Scholarship</th><th scope="col">Internship guess</th><th scope="col">Tuition used</th><th scope="col">“Net” in the brief</th></tr></thead>
        <tbody>
          <tr><td>1</td><td>$17,500</td><td>$20,000–$25,000</td><td>~$15,000</td><td>+$22,500 to +$30,000</td></tr>
          <tr><td>2</td><td>$18,000</td><td>$0</td><td>~$15,000</td><td>+$3,000</td></tr>
          <tr><td>3</td><td>$9,500 + $9,500 incentive</td><td>$25,000–$35,000</td><td>~$15,000</td><td>+$29,000 to +$39,000</td></tr>
          <tr><th scope="row">Total</th><td>$54,000</td><td>$45,000–$60,000</td><td>~$45,000</td><td>+$54,000 to +$69,000</td></tr>
        </tbody>
      </table></div>
      <p>If internships are unpaid, the scholarship still exceeds a $45,000 tuition estimate on paper, but you have no wage in the placement semesters and HECS may still sit as a loan. If the lower weekly rates are right, add roughly $10,000–$21,000 per paid placement instead.</p>
      ${pager(["section2.html","Subjects and majors"], ["section4.html","Internships"])}
  `,
});

put("sections/section4.html", {
  title: "Internships · UTS BAcc Co-op guide",
  description: "UTS BAcc internships: timing, sponsors, matching, daily work, assessment and graduate offers.",
  body: `
      <p class="kicker">Section 04</p>
      <h1>Industry internships</h1>
      <p class="deck">Two full-time placements, six months each, at different sponsors. You study two subjects at the same time. You can ask for a sector. You cannot book a company.</p>
      ${toc([["when","When they run"],["who","Sponsors"],["match","How matching works"],["day","What the work looks like"],["pay","Pay, hours, place"],["support","Feedback"],["jobs","Graduate offers"]])}
      <h2 id="when">When they run</h2>
      <div class="table-scroll"><table>
        <caption>Twelve months of full-time work, split across the degree.</caption>
        <thead><tr><th scope="col"></th><th scope="col">Internship 1</th><th scope="col">Internship 2</th></tr></thead>
        <tbody>
          <tr><th scope="row">When</th><td>July–November, year 1 spring</td><td>March–June, year 3 autumn</td></tr>
          <tr><th scope="row">Work</th><td>Full-time, Monday to Friday</td><td>Full-time, Monday to Friday</td></tr>
          <tr><th scope="row">Study beside it</th><td>Two UTS subjects</td><td>Two UTS subjects. The later map names audit and the capstone.</td></tr>
        </tbody>
      </table></div>
      <h2 id="who">Sponsors named for a 2027-style intake</h2>
      <p>The brief says “28+” and then names the organisations below. Thinkmill appears only in the longer list. Deloitte is discussed later as a Big Four employer and is not in the sponsor list. Lists change. Ask which firms are taking interns in your year. The brief places all of these headquarters in Sydney.</p>
      <h3>Accounting and advisory</h3>
      <ul class="sponsor-grid">
        <li><strong>EY</strong><span>Professional services</span></li>
        <li><strong>KPMG</strong><span>Professional services</span></li>
        <li><strong>PwC</strong><span>Professional services</span></li>
        <li><strong>BDO</strong><span>Professional services</span></li>
        <li><strong>Pitcher Partners</strong><span>Mid-tier</span></li>
        <li><strong>KordaMentha</strong><span>Restructuring and forensic</span></li>
      </ul>
      <h3>Banks, markets and insurance</h3>
      <ul class="sponsor-grid">
        <li><strong>Commonwealth Bank</strong><span>Banking</span></li>
        <li><strong>Westpac</strong><span>Banking</span></li>
        <li><strong>Macquarie Group</strong><span>Investment banking</span></li>
        <li><strong>Perpetual</strong><span>Funds management</span></li>
        <li><strong>MA Financial Group</strong><span>Financial services</span></li>
        <li><strong>ASX</strong><span>Markets</span></li>
        <li><strong>Cuscal</strong><span>Payments</span></li>
        <li><strong>QBE</strong><span>Insurance</span></li>
        <li><strong>Allianz Australia</strong><span>Insurance</span></li>
      </ul>
      <h3>Property</h3>
      <ul class="sponsor-grid">
        <li><strong>Dexus</strong><span>Property</span></li>
        <li><strong>Frasers Property</strong><span>Property</span></li>
        <li><strong>GPT Group</strong><span>Property</span></li>
        <li><strong>Lendlease</strong><span>Property and construction</span></li>
        <li><strong>Mirvac</strong><span>Property</span></li>
        <li><strong>Stockland</strong><span>Property</span></li>
      </ul>
      <h3>Other industries</h3>
      <ul class="sponsor-grid">
        <li><strong>Coca-Cola Europacific Partners</strong><span>Beverages</span></li>
        <li><strong>Merivale</strong><span>Hospitality</span></li>
        <li><strong>THE ICONIC</strong><span>E-commerce</span></li>
        <li><strong>JD Sports</strong><span>Retail</span></li>
        <li><strong>GrainCorp</strong><span>Agriculture</span></li>
        <li><strong>Ingham’s</strong><span>Food and manufacturing</span></li>
        <li><strong>NSW Health</strong><span>Public sector</span></li>
        <li><strong>News Corp Australia</strong><span>Media</span></li>
        <li><strong>Thinkmill</strong><span>Technology. Named only in the longer list.</span></li>
      </ul>
      <h2 id="match">How matching works</h2>
      <p>The brief calls allocation “a bit of an art”. You nominate a sector. UTS weighs that against your results, your interview, vacancies and skill fit, then decides. A named company is not guaranteed. The second internship is more open: you can express a department preference. The first role is largely the sponsor’s call. Areas named: finance, accounting, tax, audit, commercial and management accounting.</p>
      <div class="callout callout-info"><p class="callout-label">If your goal is a specific desk</p><p>Say so early, and keep your results strong. Preference is an input, not a booking. A student aiming at investment banking could still be placed in property accounting.</p></div>
      <h2 id="day">What the work looks like</h2>
      <article class="panel"><h3>Year 1 example: Coca-Cola Europacific Partners</h3><p>Management accounting assistant. Month-end support, journals, reconciliations, management reports, budgeting, SAP, variance analysis, and two research projects.</p></article>
      <article class="panel"><h3>Year 3 example: AMP Capital</h3><p>Property accounting analyst. Portfolio accounts, investment-property statements, performance, impairment, leases, capital expenditure, and two projects for senior people. AMP Capital is the example. It is not in the sponsor list above, so treat it as a type of role, not a current sponsor.</p></article>
      <h2 id="pay">Pay, hours, place</h2>
      <ul>
        <li>Hours: 37.5–40 a week, plus 5–10 hours for the two subjects. Mostly greater Sydney.</li>
        <li>Leave follows the employer, not the university. The brief suggests 2–4 weeks of annual leave is typical. It does not say interns receive it.</li>
        <li>Pay: see the money section. The brief assumes it and never documents it.</li>
      </ul>
      <h2 id="support">Feedback</h2>
      <p>Beforehand: a company induction and a UTS briefing. During: monthly check-ins and a formal review. Afterwards: you write a report, and performance is said to contribute to your academic record. No grade weighting is given. A weak review can hurt the next placement and a graduate offer.</p>
      <h2 id="jobs">Graduate offers</h2>
      <p>Sponsors recruit in the first half of year 3. Offers can come from your internship employer, another sponsor, or outside. Michelle Cook’s figure is 95% or better over 37 years. Another line in the brief says “100% historic employment rate”. Average starting salary in the brief is about $65,000. You need not accept. You are not assured of your first-choice sponsor. The $9,500 incentive applies only to a qualifying sponsor hire. Permanent offers during a placement are described as more common after internship 2. Brendan Dunne (class of 2003) is quoted as staying at Allianz after an internship there.</p>
      <figure class="quote"><blockquote><p>“Most UTS BAcc graduates spend the first two-to-three years after university in a graduate development program with one of our sponsoring employers.”</p></blockquote><figcaption>Michelle Cook, as quoted in the brief.</figcaption></figure>
      ${pager(["section3.html","Scholarship and money"], ["section5.html","Versus cadetships"])}
  `,
});

console.log("3-4");
