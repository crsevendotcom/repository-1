//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Yy5weajF.js
var tsrStartManifest = () => ({ routes: { __root__: {
	filePath: "/workspace/src/routes/__root.tsx",
	children: [
		"/",
		"/index.html",
		"/sections/$"
	],
	preloads: ["/assets/index-Ba7oW775.js"],
	scripts: [{ attrs: {
		type: "module",
		async: !0,
		src: "/assets/index-Ba7oW775.js"
	} }]
} } });
//#endregion
export { tsrStartManifest };
