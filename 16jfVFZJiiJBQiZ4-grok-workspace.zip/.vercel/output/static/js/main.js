(function () {
  var nav = document.getElementById("site-nav");
  var toggle = document.querySelector("[data-nav-toggle]");
  var backdrop = document.querySelector("[data-nav-backdrop]");
  var progress = document.querySelector("[data-progress]");

  function setOpen(open) {
    if (!nav || !toggle) return;
    nav.classList.toggle("is-open", open);
    toggle.setAttribute("aria-expanded", open ? "true" : "false");
    if (backdrop) backdrop.hidden = !open;
    document.body.style.overflow = open ? "hidden" : "";
  }

  if (toggle && nav) {
    toggle.addEventListener("click", function () {
      setOpen(!nav.classList.contains("is-open"));
    });
  }
  if (backdrop) {
    backdrop.addEventListener("click", function () { setOpen(false); });
  }
  document.addEventListener("keydown", function (event) {
    if (event.key === "Escape") setOpen(false);
  });
  if (nav) {
    nav.querySelectorAll("a").forEach(function (link) {
      link.addEventListener("click", function () { setOpen(false); });
    });
  }

  function normalizePath(pathname) {
    var path = pathname.replace(/\/index\.html$/, "/");
    if (path.length > 1 && path.endsWith("/")) path = path.slice(0, -1);
    return path || "/";
  }

  var path = normalizePath(location.pathname);
  document.querySelectorAll("#site-nav a").forEach(function (link) {
    var linkPath = normalizePath(new URL(link.getAttribute("href") || ".", location.href).pathname);
    if (linkPath === path) link.setAttribute("aria-current", "page");
  });

  function onScroll() {
    if (!progress) return;
    var doc = document.documentElement;
    var max = doc.scrollHeight - doc.clientHeight;
    var ratio = max > 0 ? Math.min(1, window.scrollY / max) : 0;
    progress.style.width = (ratio * 100).toFixed(2) + "%";
  }
  onScroll();
  window.addEventListener("scroll", onScroll, { passive: true });

  document.querySelectorAll(".table-scroll").forEach(function (wrap) {
    if (!wrap.getAttribute("tabindex")) wrap.setAttribute("tabindex", "0");
    if (!wrap.getAttribute("aria-label")) {
      wrap.setAttribute("aria-label", "Scrollable table. Swipe or use arrow keys horizontally.");
    }
  });

  var filterForm = document.querySelector("[data-filter-form]");
  if (filterForm) {
    filterForm.addEventListener("submit", function (event) { event.preventDefault(); });
  }

  var filter = document.querySelector("[data-filter]");
  var cards = document.querySelectorAll("[data-keywords]");
  var empty = document.querySelector("[data-filter-empty]");
  if (filter) {
    filter.addEventListener("input", function () {
      var q = filter.value.trim().toLowerCase();
      var shown = 0;
      cards.forEach(function (card) {
        var hay = (card.getAttribute("data-keywords") || card.textContent || "").toLowerCase();
        var match = !q || hay.indexOf(q) !== -1;
        card.hidden = !match;
        if (match) shown += 1;
      });
      if (empty) empty.hidden = shown !== 0;
    });
  }

  document.querySelectorAll("[data-expand]").forEach(function (button) {
    button.addEventListener("click", function () {
      var root = document.querySelector(button.getAttribute("data-expand"));
      if (!root) return;
      var open = button.getAttribute("data-state") !== "open";
      root.querySelectorAll("details").forEach(function (item) { item.open = open; });
      button.setAttribute("data-state", open ? "open" : "closed");
      button.textContent = open ? "Collapse all" : "Expand all";
    });
  });

  var form = document.querySelector("[data-fit]");
  if (!form) return;

  var WEIGHTS = {
    speed: { bacc: 2, big4: 0, mid: 0, trad: 1 },
    guarantee: { bacc: 0, big4: 3, mid: 3, trad: 0 },
    scholarship: { bacc: 2, big4: 1, mid: 1, trad: 0 },
    breadth: { bacc: 3, big4: 0, mid: 1, trad: 1 },
    depth: { bacc: 0, big4: 3, mid: 2, trad: 0 },
    campus: { bacc: 2, big4: 0, mid: 0, trad: 3 },
    calm: { bacc: 0, big4: 1, mid: 2, trad: 3 },
    corporate: { bacc: 3, big4: 1, mid: 1, trad: 1 },
    ib: { bacc: 1, big4: 1, mid: 0, trad: 3 },
    steady: { bacc: 0, big4: 3, mid: 3, trad: 0 },
    flexible: { bacc: 1, big4: 0, mid: 0, trad: 3 },
    atar: { bacc: 0, big4: 1, mid: 2, trad: 2 }
  };
  var LABELS = {
    bacc: "UTS BAcc Co-op",
    big4: "Big Four cadetship",
    mid: "Mid-tier cadetship",
    trad: "Traditional commerce degree"
  };
  var NOTES = {
    bacc: "Fits a fast, practical path: scholarship, two employers, campus cohort, and corporate sponsors. It does not guarantee a graduate job.",
    big4: "Fits someone who wants one firm, a steadier wage while studying, and a graduate seat at the end. University life is thinner and the degree usually takes longer.",
    mid: "Similar security to a Big Four cadetship, often with less competition and more varied day-to-day work, at the cost of a smaller brand.",
    trad: "Fits flexibility, a standard pace, or a goal such as investment banking that wants a deeper finance degree than accounting co-op provides."
  };

  var result = document.querySelector("[data-fit-result]");
  var STORAGE = "bacc-fit-v1";

  function selected() {
    return Array.prototype.map.call(
      form.querySelectorAll('input[name="priority"]:checked'),
      function (input) { return input.value; }
    );
  }

  function render(values) {
    if (!result) return;
    if (!values.length) {
      result.innerHTML = "<p>Select at least one priority. This tool only reflects the guide. It is not advice from UTS.</p>";
      return;
    }
    var totals = { bacc: 0, big4: 0, mid: 0, trad: 0 };
    values.forEach(function (key) {
      var row = WEIGHTS[key];
      if (!row) return;
      Object.keys(totals).forEach(function (id) { totals[id] += row[id] || 0; });
    });
    var ranked = Object.keys(totals).sort(function (a, b) { return totals[b] - totals[a]; });
    var max = totals[ranked[0]] || 1;
    var ib = values.indexOf("ib") !== -1;
    var html = "<h3>Leans toward " + LABELS[ranked[0]] + "</h3>";
    html += "<p>" + NOTES[ranked[0]] + "</p>";
    if (ib && ranked[0] !== "trad") {
      html += "<p>You also marked highly technical finance. The guide rates a dedicated finance degree ahead of BAcc for investment banking, even if co-op wins your other priorities.</p>";
    }
    html += '<ol class="score">';
    ranked.forEach(function (id) {
      var pct = Math.round((totals[id] / max) * 100);
      html += "<li><span>" + LABELS[id] + "</span><span class=\"bar\" aria-hidden=\"true\"><span style=\"width:" + pct + "%\"></span></span><strong>" + totals[id] + "</strong></li>";
    });
    html += "</ol><p>Scores are a transparent tally of the priorities you ticked, using the trade-offs in this guide. Read the matching sections before you decide.</p>";
    result.innerHTML = html;
  }

  try {
    var saved = JSON.parse(localStorage.getItem(STORAGE) || "[]");
    if (Array.isArray(saved)) {
      saved.forEach(function (value) {
        var box = form.querySelector('input[value="' + value + '"]');
        if (box) box.checked = true;
      });
      if (saved.length) render(saved);
    }
  } catch (err) { /* ignore private-mode storage */ }

  form.addEventListener("submit", function (event) {
    event.preventDefault();
    var values = selected();
    try { localStorage.setItem(STORAGE, JSON.stringify(values)); } catch (err) { /* ignore */ }
    render(values);
    if (result) result.focus();
  });

  var reset = form.querySelector("[data-fit-reset]");
  if (reset) {
    reset.addEventListener("click", function () {
      form.reset();
      try { localStorage.removeItem(STORAGE); } catch (err) { /* ignore */ }
      if (result) result.innerHTML = "";
    });
  }
})();
