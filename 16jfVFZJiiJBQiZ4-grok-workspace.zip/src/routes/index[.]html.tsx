import { createFileRoute } from "@tanstack/react-router";
import indexHtml from "../../uts-bacc-website/index.html?raw";

export const Route = createFileRoute("/index.html")({
  server: {
    handlers: {
      GET: () =>
        new Response(indexHtml, {
          headers: {
            "content-type": "text/html; charset=utf-8",
            "cache-control": "no-cache",
          },
        }),
    },
  },
});
