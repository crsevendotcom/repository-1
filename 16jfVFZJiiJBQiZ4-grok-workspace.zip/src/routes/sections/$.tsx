import { createFileRoute } from "@tanstack/react-router";
import section1 from "../../../uts-bacc-website/sections/section1.html?raw";
import section2 from "../../../uts-bacc-website/sections/section2.html?raw";
import section3 from "../../../uts-bacc-website/sections/section3.html?raw";
import section4 from "../../../uts-bacc-website/sections/section4.html?raw";
import section5 from "../../../uts-bacc-website/sections/section5.html?raw";
import section6 from "../../../uts-bacc-website/sections/section6.html?raw";
import section7 from "../../../uts-bacc-website/sections/section7.html?raw";
import section8 from "../../../uts-bacc-website/sections/section8.html?raw";
import section9 from "../../../uts-bacc-website/sections/section9.html?raw";
import section10 from "../../../uts-bacc-website/sections/section10.html?raw";
import section11 from "../../../uts-bacc-website/sections/section11.html?raw";
import section12 from "../../../uts-bacc-website/sections/section12.html?raw";

const pages: Record<string, string> = {
  "section1.html": section1,
  "section2.html": section2,
  "section3.html": section3,
  "section4.html": section4,
  "section5.html": section5,
  "section6.html": section6,
  "section7.html": section7,
  "section8.html": section8,
  "section9.html": section9,
  "section10.html": section10,
  "section11.html": section11,
  "section12.html": section12,
};

export const Route = createFileRoute("/sections/$")({
  server: {
    handlers: {
      GET: ({ params }) => {
        const html = pages[params._splat ?? ""];
        if (!html) {
          return new Response("Not found", {
            status: 404,
            headers: { "content-type": "text/plain; charset=utf-8" },
          });
        }
        return new Response(html, {
          headers: {
            "content-type": "text/html; charset=utf-8",
            "cache-control": "no-cache",
          },
        });
      },
    },
  },
});
